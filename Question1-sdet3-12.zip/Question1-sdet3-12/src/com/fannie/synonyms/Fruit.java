package com.fannie.synonyms;

public enum Fruit {
Grape,Banana,Pineapple,Apple,Tomato
}
