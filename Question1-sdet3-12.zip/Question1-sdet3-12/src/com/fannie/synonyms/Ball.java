package com.fannie.synonyms;

public enum Ball {
Globe,Sphere,Round
}
