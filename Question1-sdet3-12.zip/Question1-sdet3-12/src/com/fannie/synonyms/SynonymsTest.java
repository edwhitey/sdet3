package com.fannie.synonyms;

import java.util.Scanner;

/*
 * This does the first part of Question 1, it populates a map and lets us look up a synonym
 * It does not do the last part using Class.forName("") or counting to the DB
 * I'm unsure how to accomplish.
 * 
 * To run this program, enter a search term from the keyboard
 */


public class SynonymsTest {

	public static void main(String[] args) {
		
	 Scanner scanner = new Scanner(System.in);
	    System.out.println("Valid words are Ball, Vehicle, Fruit ");
	   System.out.println("Type in a word to search: ");
	   String key = scanner.nextLine();
	   
	   Synonym lookup = new Synonym(key);

	}
	}
