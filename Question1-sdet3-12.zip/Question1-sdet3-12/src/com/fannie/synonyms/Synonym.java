package com.fannie.synonyms;

import java.sql.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Synonym {
	private String key;

	public Synonym(String key) {
		super();
		this.key = key;

		Map<String, List<?>> lookup = new HashMap<String, List<?>>();

		// create list one and store values from enum
		List<Fruit> word1 = Arrays.asList(Fruit.values());

		// create list two and store values from enum
		List<Ball> word2 = Arrays.asList(Ball.values());

		// create list three and store values from enum
		List<Vehicle> word3 = Arrays.asList(Vehicle.values());

		// put values into map based on keywords
		lookup.put("Fruit", word1);
		lookup.put("Ball", word2);
		lookup.put("Vehicle", word3);

		try {
			if (lookup.get(key) != null) {
				System.out.println(lookup.get(key));
			} else {
				throw new RuntimeException("Sorry, word not found in dictionary");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		incrementer(key); 

	}// constructor

	// this method should pull the key provided from the Db, increment its
	// counter and then give a
	// full report on all synonym calls.

	void incrementer(String key) {
		int counter; // will draw from DB to get current count for key and then
						// be incremented

		try {
			// 1 get connection to db
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost/dbname");
			// 2 create statement
			Statement myStat = myConn.createStatement();
			// 3 execute query
			ResultSet myRs = myStat.executeQuery("select counter from synonyms where key = '" + key + "'");
			// 4 process results
			counter = myRs.getInt("counter");
			// increment the counter
			counter++;
			// then put incremented counter back into db
			String sql = "update synonyms" + "set counter = ' " + counter + " ' " + "where key = ' " + key + " ' ";

			myStat.executeUpdate(sql);
			// System.out.println(key +" has been called "+counter);

			System.out.println("Synonym usage report:");
			ResultSet report = myStat.executeQuery("select * from synonyms");
			while (report.next()) {
				System.out.println(report.getString("key") + " has been queried " + report.getInt("counter") + "times.");
			}
			myConn.close();
		} catch (SQLException e) {
					e.printStackTrace();
		}

	} // end iterator

}// class
