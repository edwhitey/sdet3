package com.fannie.synonyms;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Synonym {
	private String key;

	public Synonym(String key) {
		super();
		this.key = key;

	
		Map<String, List<?>> lookup = new HashMap<String, List<?>>();

		// create list one and store values from enum
	    List<Fruit> word1 = Arrays.asList(Fruit.values());

		// create list two and store values from enum
	   List<Ball> word2 = Arrays.asList(Ball.values());


		// create list three and store values from enum
	   List<Vehicle> word3 = Arrays.asList(Vehicle.values());

		// put values into map based on keywords
	lookup.put("Fruit", word1);
	lookup.put("Ball", word2);
	lookup.put("Vehicle", word3);	

		try {
			if(lookup.get(key)!=null){
						System.out.println(lookup.get(key));
			}else{throw new RuntimeException ("Sorry, word not found in dictionary");}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
}// constructor

}// class
