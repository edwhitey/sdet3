package com.fannie.synonyms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBconnection {

	//this was basically cut & paste from the class slides. I really don't have a handle on this yet
	
public static void main(String[] args) {
		Connection conn = null;
		try {
			String userName = "root";
			String password = "root";
			String url = "jdbc:mysql://localhost/test";
			Class.forName("com.mysql.jdbc.Driver");
			Properties connectionProps = new Properties();
			connectionProps.put("user", userName);
			connectionProps.put("password", password);
			conn = DriverManager.getConnection(url, connectionProps);
			System.out.println("Database connection successful");
		} catch (SQLException e) {
			System.err.println("Failed to connect to database" + e);
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}

			}
		}

	}
}
