package com.fannie.synonyms;

public enum Vehicle {
Car,Truck,Plane,Motorcycle
}
