package com.fannie.soap.timeserver;

import javax.jws.WebMethod;
import javax.jws.WebService;

/** 
*  All Contracts will go here 
*
*/

@WebService
public interface TimeServer {
	
	@WebMethod
	public String getTimeAsString();
	
	@WebMethod
	public String getTimeFromServer();
	
	@WebMethod
	public String getTicketFare(String src, String dest);
	
	@WebMethod
	public String checkCreditScore(String name, int score);
	
}
