package com.fannie.bank;

public interface DepositAcc extends Account {


	public void  withdraw(String acctName, double withdraw, double balance);
	public void  deposit(String acctName, double deposit, double balance);
	public void  getBalance(String acctName);
	
	
	
}
