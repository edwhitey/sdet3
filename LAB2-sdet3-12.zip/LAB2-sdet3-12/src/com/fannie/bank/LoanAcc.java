package com.fannie.bank;

public interface LoanAcc extends Account{

	public void  repayPrinciple(String acctName, double prinAmt);
	public void  payInterest(String acctName, double intAmt);
	public void  payPartialPrinciple(String acctName, double parPrinAmt );
}
