package com.fannie.bank;

public interface Interest {

	double savingInt = 1.6;
	double fixedInt = 1.8;
	double persInt = 3.5;
	double houseInt = 3.75;
	
	public double  calcInt(double balance);
	
	
}
