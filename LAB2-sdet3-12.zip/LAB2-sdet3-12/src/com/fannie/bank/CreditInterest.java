package com.fannie.bank;

public interface CreditInterest extends Interest {

	public void  addMonthlyInt(String acctName, double balance);
	public void  addHalfYrlyInt(String acctNamet, double balance);
	public void  addAnnualInt(String acctName, double balance);
	
}
