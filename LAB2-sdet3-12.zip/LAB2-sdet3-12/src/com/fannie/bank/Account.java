package com.fannie.bank;

public interface Account {

	String savingAcct = "Savings";
	String fixedAcct = "Fixed";
	String personalAcct = "PersonalLoan";
	String housingAcct = "HousingLoan";
	
	public String createAcc(String acctName, double balance);	
}
