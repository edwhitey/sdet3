package com.fannie.bank;

public interface DebitInterest extends Interest {

	public void  deductMonthlyInt(String acctName, double balance);
	public void  deductHalfYrlyInt(String acctName, double balance);
	public void  deductAnnualInt(String acctNamet, double balance);
	
	
	
	
}
