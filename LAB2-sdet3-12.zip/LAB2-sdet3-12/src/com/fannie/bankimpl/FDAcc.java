package com.fannie.bankimpl;

import com.fannie.bank.CreditInterest;
import com.fannie.bank.DepositAcc;
import com.fannie.bank.Interest;

public class FDAcc implements DepositAcc, CreditInterest{

	private String acctName;
	private double amount;
	private double balance;
	private double deposit;
	private double withdraw;
	
	
	@Override
	public String createAcc(String acctName, double balance) {
		this.acctName = acctName;
		this.balance=balance;
		// in real world this method would create a database entry 
		//for the new account with the starting balance.
		System.out.printf("FD createAcc method created a %s account with balance %.2f %n", acctName,balance);
		return acctName;

	}
	@Override
	public double calcInt(double balance) {
	balance = balance + (balance * Interest.savingInt)/100;
	//real world the balance would come from the db via getBalance
	System.out.printf("FD calcInt method - account balance is $%.2f, using interest rate of %.2f %% %n", balance, Interest.savingInt);
return balance;
	}


@Override
public void addMonthlyInt(String acctName, double balance) {
	//real world the balance would come from the db via getBalance
	System.out.printf("FD addMonthlyInt method being passed type %s and balance %.2f %n",acctName, balance);
	//code would be written to calculate  interest 
	//based on account type and the current balance

}
@Override
public void addHalfYrlyInt(String acctName, double balance) {
	//real world the balance would come from the db via getBalance
	System.out.printf("FD addHalfYrlyInt method being passed type %s and balance %.2f %n",acctName, balance);
	//code would be written to calculate  interest 
	//based on account type and the current balance

}
@Override
public void addAnnualInt(String acctName, double balance) {
	//real world the balance would come from the db via getBalance
	System.out.printf("FD addAnnualInt method being passed type %s and balance %.2f %n",acctName, balance);
	//code would be written to calculate  interest 
	//based on account type and the current balance

}
@Override
public void withdraw(String acctName, double withdraw, double balance) {
	//code would be written to balance remaining after withdraw action
	//real world the balance would come from the db via getBalance
	// manipulating the values then updating
	//based on account type  the current balance and withdraw amount
	this.withdraw = withdraw;
	this.balance=balance;
	System.out.printf("FD withdraw method being passed type %s, withdraw %.2f  and balance %.2f %n",acctName, withdraw, balance);
	balance = balance -withdraw;

}

@Override
public void deposit(String acctName, double deposit, double balance) {
	//code would be written to calculate balance after deposit action 
	//real world the balance would come from the db via getBalance
	//  manipulating the values then updating
	//based on account type and the current balance and deposit amount
	this.deposit = deposit;
	this.balance = balance;
	System.out.printf("FD deposit method being passed type %s, deposit %.2f  and balance %.2f %n",acctName, deposit, balance);
	balance = balance + deposit;

}
@Override
public void getBalance(String acctName) {
	System.out.printf("FD getBalance method being passed type %s.  Would return value from database.%n",acctName);
		this.balance=balance;
	//code would be written to retrieve balance 
	// in real world I'd be pulling from a database
	//based on account type I'm just showing that I'm making a method call here

}


}
