package com.fannie.bankimpl;

import com.fannie.bank.DebitInterest;
import com.fannie.bank.Interest;
import com.fannie.bank.LoanAcc;

public class HousingLoanAcc implements LoanAcc, DebitInterest{

	private String acctName;
	private double amount;
	private double balance;
	private double deposit;
	private double withdraw;
	
	@Override
	public String createAcc(String acctName, double balance) {
		this.acctName = acctName;
		this.balance=balance;
		// in real world this method would create a database entry 
		//for the new account with the starting balance.
		System.out.printf("Housing createAcc method created a %s account with balance %.2f %n", acctName,balance);
		return acctName;

	}
	@Override
		public double calcInt(double balance) {
		//real world the balance would come from the db
		balance = balance + (balance * Interest.houseInt)/100;
		System.out.printf("Housing calcInt method - account balance is $%.2f, using interest rate of %.2f %% %n", balance, Interest.savingInt);
	return balance;
		}


	@Override
	public void deductMonthlyInt(String acctName, double balance) {
		System.out.printf("Housing deductMonthlyInt method being passed type %s and balance %.2f %n",acctName, balance);
		//real world the balance would come from the db
		//code would be written to calculate interest 
		//based on account type and the current balance

	}
	@Override
	public void deductHalfYrlyInt(String acctName, double balance) {
		System.out.printf("Housing deductHalfYrlyInt method being passed type %s and balance %.2f %n",acctName, balance);
		//real world the balance would come from the db 
		//code would be written to calculate  interest 
		//based on account type and the current balance

	}
	@Override
	public void deductAnnualInt(String acctName, double balance) {
		System.out.printf("Housing deductAnnualInt method being passed type %s and balance %.2f %n",acctName, balance);
		//real world the balance would come from the db 
		//code would be written to calculate  interest 
		//based on account type and the current balance

	}
	
	
	
	@Override
	public void repayPrinciple(String acctName, double prinAmt) {
		System.out.printf("Housing repayPrinciple method being passed type %s and amount %.2f %n",acctName, prinAmt);
		//code would be written to calculate  change in principle 
		//based on account type and the amount paid

		
	}
	
	@Override
	public void payPartialPrinciple(String acctName, double parPrinAmt) {
		System.out.printf("Housing payPartialPrinciple method being passed type %s and amount %.2f %n",acctName, parPrinAmt);
		//code would be written to calculate  change in principle 
		//based on account type and the amount paid

		
	}
	@Override
	public void payInterest(String acctName, double intAmt) {
		System.out.printf("Housing  payInterest method being passed type %s and amount %.2f %n",acctName, intAmt);
		//code would be written to calculate  change in amount 
		//based on account type and the interest amount paid

		
	}

	
}
