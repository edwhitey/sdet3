package com.fannie.bankimpl;

import java.util.Scanner;

import com.fannie.bank.Account;

public class MyAccount {

	/**
	 * Account name must be: Savings, Fixed, PersonalLoan, or HousingLoan. Each
	 * method will return a screen printout
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		SavingsAcc saving = new SavingsAcc();
		FDAcc fd = new FDAcc();
		PersonalLoanAcc pla = new PersonalLoanAcc();
		HousingLoanAcc hla = new HousingLoanAcc();
		
		// input an account name: Savings, Fixed, PersonalLoan, or HousingLoan
		// input a starting balance
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter an account name ");
		String acctName = scanner.nextLine();
		System.out.println("Enter a starting balance ");
		double balance = scanner.nextDouble();
		
			
		if (acctName.equals(Account.savingAcct)) {
			System.out.printf("Input from keyboard - Account: %s, starting balance of $%.2f %n", acctName, balance);
			saving.createAcc(acctName, balance);
			balance = saving.calcInt(balance);
			saving.addMonthlyInt(acctName, balance);
			saving.addAnnualInt(acctName, balance);
			saving.addHalfYrlyInt(acctName, balance);
			//enter a deposit amount
			System.out.println("Enter a deposit amount: ");
			double deposit = scanner.nextDouble();
			saving.deposit(acctName, deposit, balance);
			//enter a withdraw amount
			System.out.println("Enter a withdraw amount: ");
			double withdraw = scanner.nextDouble();
			saving.withdraw(acctName, withdraw, balance);
			saving.getBalance(acctName);

		} else if (acctName.equals(Account.fixedAcct)) {

			System.out.printf("Input from keyboard - Account: %s, starting balance of $%.2f %n", acctName, balance);
			fd.createAcc(acctName, balance);
			balance = fd.calcInt(balance);
			fd.addMonthlyInt(acctName, balance);
			fd.addAnnualInt(acctName, balance);
			fd.addHalfYrlyInt(acctName, balance);
			//enter a deposit amount
			System.out.println("Enter a deposit amount: ");
			double deposit = scanner.nextDouble();
			fd.deposit(acctName, deposit, balance);
			//enter a withdraw amount
			System.out.println("Enter a withdraw amount: ");
			double withdraw = scanner.nextDouble();
			fd.withdraw(acctName, withdraw, balance);
			fd.getBalance(acctName);
			
		} else if (acctName.equals(Account.housingAcct)) {

			System.out.printf("Input from keyboard - Account: %s, starting balance of $%.2f %n", acctName, balance);
			hla.createAcc(acctName, balance);
			balance = hla.calcInt(balance);
			hla.deductMonthlyInt(acctName, balance);
			hla.deductAnnualInt(acctName, balance);
			hla.deductHalfYrlyInt(acctName, balance);
			//enter a principle amount
			System.out.println("Enter principle amount paid: ");
			double prinAmt = scanner.nextDouble();
			hla.repayPrinciple(acctName, prinAmt);
			//enter a partial principle amount
			System.out.println("Enter partial principle amount paid: ");
			double parPrinAmt = scanner.nextDouble();
			hla.payPartialPrinciple(acctName, parPrinAmt);
			//enter a partial principle amount
			System.out.println("Enter interest amount paid: ");
			double intAmt = scanner.nextDouble();
			hla.payInterest(acctName, intAmt);
				

		} else if (acctName.equals(Account.personalAcct)) {

			System.out.printf("Input from keyboard - Account: %s, starting balance of $%.2f %n", acctName, balance);
			pla.createAcc(acctName, balance);
			balance = pla.calcInt(balance);
			pla.deductMonthlyInt(acctName, balance);
			pla.deductAnnualInt(acctName, balance);
			pla.deductHalfYrlyInt(acctName, balance);
			//enter a principle amount
			System.out.println("Enter principle amount paid: ");
			double prinAmt = scanner.nextDouble();
			pla.repayPrinciple(acctName, prinAmt);
			//enter a partial principle amount
			System.out.println("Enter partial principle amount paid: ");
			double parPrinAmt = scanner.nextDouble();
			pla.payPartialPrinciple(acctName, parPrinAmt);
			//enter a partial principle amount
			System.out.println("Enter interest amount paid: ");
			double intAmt = scanner.nextDouble();
			pla.payInterest(acctName, intAmt);
			
		} else {
			System.out.println("Unknown Account Type");
			System.out.println("Valid types:  Savings, Fixed, PersonalLoan, HousingLoan");
		}
		scanner.close();
	}// main
} // class
